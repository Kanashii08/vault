<?php
$string['pluginname'] = 'Admin & Security Settings';
$string['settings'] = 'Settings';