<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_adminsec';
$plugin->version   = 2025121000;    // YYYYMMDD00
$plugin->requires  = 2022112800;    // Compatible with Moodle 4.1+
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = 'v2.0 (8 Features)';