<?php
require_once('../../config.php');
require_once($CFG->libdir . '/adminlib.php');

// 1. Security Setup
require_login();
$context = context_system::instance();
require_capability('moodle/site:config', $context); // Only Admins

// --- NEW UPDATE: CHECK IF PLUGIN IS ENABLED ---
// We check the setting from Site Admin > Plugins > Local plugins > Admin & Security Settings
$is_enabled = get_config('local_adminsec', 'plugin_enabled');

// If the setting is '0' (Unchecked) or doesn't exist yet, we block access.
// (Note: We treat 'false' as disabled, but default to enabled if setting is missing to avoid lockout on first install)
if ($is_enabled === '0') {
    $PAGE->set_context($context);
    $PAGE->set_url(new moodle_url('/local/adminsec/index.php'));
    $PAGE->set_title('Plugin Disabled');
    $PAGE->set_heading('Plugin Disabled');
    $PAGE->set_pagelayout('admin');
    
    echo $OUTPUT->header();
    echo $OUTPUT->notification('This plugin has been disabled by the Site Administrator.', 'warning');
    echo '<p>To re-enable it, go to <strong>Site administration > Plugins > Local plugins > Admin & Security Settings</strong>.</p>';
    echo $OUTPUT->footer();
    die(); // STOP HERE. Do not load the rest of the features.
}
// --- END UPDATE ---

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/adminsec/index.php'));
$PAGE->set_title('Admin & Security Settings');
$PAGE->set_heading('Admin & Security Settings');
$PAGE->set_pagelayout('admin');

// 2. IP GUARD LOGIC (Protects this page)
$allowed_ips_str = get_config('local_adminsec', 'allowed_ips');
if (!empty($allowed_ips_str)) {
    $allowed_ips = array_map('trim', explode(',', $allowed_ips_str));
    $user_ip = getremoteaddr();
    // Allow if in list OR is admin (prevents locking yourself out)
    if (!in_array($user_ip, $allowed_ips) && !is_siteadmin()) {
        die("ACCESS DENIED: Your IP ($user_ip) is not allowed.");
    }
}

// 3. TAB NAVIGATION
$view = optional_param('view', 'dashboard', PARAM_ALPHA);
$tabs = [
    'dashboard' => '1. System Health',
    'ips'       => '2. IP Guard',
    'alerts'    => '3. Alerts',
    'notes'     => '4. Admin Notes',
    'users'     => '5. Force Password',
    'captcha'   => '6. Captcha Test',
    'maint'     => '7. Emergency Mode',
    'sessions'  => '8. Kill Sessions',
];

echo $OUTPUT->header();

// Draw Tabs
echo '<ul class="nav nav-tabs" style="margin-bottom: 20px;">';
foreach ($tabs as $key => $name) {
    $active = ($view === $key) ? 'active' : '';
    $url = new moodle_url('/local/adminsec/index.php', ['view' => $key]);
    echo "<li class='nav-item'><a class='nav-link $active' href='$url'>$name</a></li>";
}
echo '</ul>';

echo '<div class="card p-4 shadow-sm">';

// 4. SWITCH LOGIC (The 8 Features)
switch ($view) {

    // FEATURE 1: DASHBOARD
    case 'dashboard':
        echo "<h3>System Security Dashboard</h3>";
        $checks = [
            'PHP Version' => version_compare(phpversion(), '8.0', '>='),
            'HTTPS Encryption' => is_https(),
            'Debug Mode Hidden' => (ini_get('display_errors') == 0)
        ];
        foreach ($checks as $label => $pass) {
            $color = $pass ? '#d4edda' : '#f8d7da';
            $icon = $pass ? '✅ OK' : '❌ RISK';
            echo "<div style='background: $color; padding: 15px; margin-bottom: 5px; border-radius:4px;'><strong>$label:</strong> $icon</div>";
        }
        break;

    // FEATURE 2: IP GUARD
    case 'ips':
        if ($data = data_submitted() && confirm_sesskey()) {
            set_config('allowed_ips', optional_param('ip_list', '', PARAM_TEXT), 'local_adminsec');
            echo $OUTPUT->notification('IP Whitelist Saved', 'success');
        }
        $curr_ip = get_config('local_adminsec', 'allowed_ips');
        echo "<h3>IP Guard Settings</h3>";
        echo "<p>Your IP: <strong>" . getremoteaddr() . "</strong></p>";
        echo "<form method='post'><input type='hidden' name='sesskey' value='".sesskey()."'>";
        echo "<label>Allowed IPs (Comma separated):</label>";
        echo "<textarea name='ip_list' class='form-control' rows='3'>$curr_ip</textarea>";
        echo "<br><button class='btn btn-primary'>Save IPs</button></form>";
        break;

    // FEATURE 3: ALERTS
    case 'alerts':
        if (optional_param('trigger', 0, PARAM_INT)) {
            $message = new \core\message\message();
            $message->component = 'moodle';
            $message->name = 'instantmessage';
            $message->userfrom = $USER;
            $message->userto = $USER;
            $message->subject = 'SECURITY ALERT';
            $message->fullmessage = 'Security Breach Simulation.';
            $message->fullmessageformat = FORMAT_HTML;
            $message->fullmessagehtml = '<b style="color:red">Security Breach Simulation</b>';
            $message->smallmessage = 'Breach Detected';
            $message->notification = 1;
            message_send($message);
            echo $OUTPUT->notification('Alert Sent to Bell Icon! 🔔', 'success');
        }
        echo "<h3>Security Alert Simulator</h3>";
        echo "<a href='?view=alerts&trigger=1' class='btn btn-danger btn-lg'>⚠️ Simulate Breach</a>";
        break;

    // FEATURE 4: NOTES
    case 'notes':
        if ($data = data_submitted() && confirm_sesskey()) {
            set_config('sec_notes', optional_param('notes', '', PARAM_TEXT), 'local_adminsec');
            echo $OUTPUT->notification('Notes Saved', 'success');
        }
        $notes = get_config('local_adminsec', 'sec_notes');
        echo "<h3>Admin Security Notes</h3>";
        echo "<form method='post'><input type='hidden' name='sesskey' value='".sesskey()."'>";
        echo "<textarea name='notes' class='form-control' rows='10'>$notes</textarea><br>";
        echo "<button class='btn btn-primary'>Save Notes</button></form>";
        break;

    // FEATURE 5: FORCE PASSWORD
    case 'users':
        if ($target = optional_param('targetuser', '', PARAM_USERNAME)) {
            if ($user = $DB->get_record('user', ['username' => $target, 'deleted' => 0])) {
                set_user_preference('auth_forcepasswordchange', 1, $user);
                echo $OUTPUT->notification("User '$target' locked. Password change required.", 'success');
            } else {
                echo $OUTPUT->notification("User not found.", 'error');
            }
        }
        echo "<h3>Force Password Change</h3>";
        echo "<form method='post'><input type='hidden' name='sesskey' value='".sesskey()."'>";
        echo "<input type='text' name='targetuser' class='form-control' placeholder='Enter Username' required><br>";
        echo "<button class='btn btn-danger'>Lock User Account</button></form>";
        break;
        
    // FEATURE 6: CAPTCHA (Integrated)
    case 'captcha':
        require_once($CFG->dirroot . '/local/adminsec/classes/form/captcha_form.php');
        $mform = new \local_adminsec\form\captcha_form();
        if ($mform->is_cancelled()) {
            // do nothing
        } else if ($data = $mform->get_data()) {
             echo $OUTPUT->notification('Success! Captcha Verified.', 'success');
        }
        $mform->display();
        break;

    // FEATURE 7: EMERGENCY MAINTENANCE
    case 'maint':
        global $CFG;
        if (optional_param('toggle_maint', 0, PARAM_INT) && confirm_sesskey()) {
            if ($CFG->maintenance_enabled) {
                set_config('maintenance_enabled', 0);
                echo $OUTPUT->notification('Maintenance Mode DISABLED.', 'success');
            } else {
                set_config('maintenance_enabled', 1);
                echo $OUTPUT->notification('Maintenance Mode ENABLED.', 'warning');
            }
        }
        echo "<h3>Emergency Maintenance Switch</h3>";
        if ($CFG->maintenance_enabled) {
            echo "<div class='alert alert-danger'><strong>STATUS: OFFLINE</strong></div>";
            $btn_text = "🟢 Go Live"; $btn_class = "btn-success";
        } else {
            echo "<div class='alert alert-success'><strong>STATUS: LIVE</strong></div>";
            $btn_text = "🔴 STOP SITE"; $btn_class = "btn-danger";
        }
        echo "<form method='post'><input type='hidden' name='sesskey' value='".sesskey()."'>";
        echo "<input type='hidden' name='toggle_maint' value='1'>";
        echo "<button class='btn $btn_class btn-lg'>$btn_text</button></form>";
        break;

    // FEATURE 8: KILL SESSIONS
    case 'sessions':
        if (optional_param('kill_all', 0, PARAM_INT) && confirm_sesskey()) {
            global $DB, $USER;
            // Delete all sessions except the current admin's
            $DB->delete_records_select('sessions', "userid <> ?", [$USER->id]);
            echo $OUTPUT->notification('Success: All other users logged out.', 'success');
        }
        echo "<h3>Mass Session Logout</h3>";
        echo "<p>Use this to stop session hijacking attacks by forcing all users to re-login.</p>";
        echo "<form method='post'><input type='hidden' name='sesskey' value='".sesskey()."'>";
        echo "<input type='hidden' name='kill_all' value='1'>";
        echo "<button class='btn btn-warning'>⚠️ Force Logout All Users</button></form>";
        break;
}
echo '</div>';
echo $OUTPUT->footer();