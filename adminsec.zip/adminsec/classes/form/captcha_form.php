<?php
namespace local_adminsec\form;
defined('MOODLE_INTERNAL') || die();
require_once("$CFG->libdir/formslib.php");

class captcha_form extends \moodleform {
    public function definition() {
        global $CFG;
        $mform = $this->_form;
        
        $mform->addElement('header', 'h', 'Test Recaptcha Integration');
        $mform->addElement('html', '<p>This tool verifies that your Google Recaptcha keys are working correctly.</p>');

        if (!empty($CFG->recaptchapublickey)) {
            $mform->addElement('recaptcha', 'recaptcha_element', 'Verify:', ['https' => true]);
        } else {
            $mform->addElement('static', 'error', 'Error', '<div class="alert alert-danger">Keys missing in Site Admin!</div>');
        }
        
        $this->add_action_buttons(false, 'Check Integrity');
    }
}