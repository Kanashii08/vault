<?php
defined('MOODLE_INTERNAL') || die();

// Only show settings if the user is an admin
if ($hassiteconfig) {
    // Create the Settings Page
    $settings = new admin_settingpage('local_adminsec', get_string('pluginname', 'local_adminsec'));

    // Add the "Enable/Disable" Checkbox
    $settings->add(new admin_setting_configcheckbox(
        'local_adminsec/plugin_enabled',        // Internal name
        'Enable Admin & Security Settings',     // Label
        'Uncheck this box to disable the plugin features completely.', // Description
        1                                       // Default: 1 = Enabled
    ));

    // Add it to the "Local Plugins" category
    $ADMIN->add('localplugins', $settings);
}